CREATE DATABASE TechNovaDB;
USE TechNovaDB;
CREATE TABLE Department (
    DeptID INT PRIMARY KEY,
    DeptName VARCHAR(50) UNIQUE,
    Location VARCHAR(50)
);

CREATE TABLE Employee (
    EmpID INT PRIMARY KEY,
    EmpName VARCHAR(50),
    Gender CHAR(1),
    DOB DATE,
    HireDate DATE,
    DeptID INT,
    FOREIGN KEY (DeptID) REFERENCES Department(DeptID)
);
CREATE TABLE Project (
    ProjectID INT PRIMARY KEY,
    ProjectName VARCHAR(50),
    DeptID INT,
    StartDate DATE,
    EndDate DATE,
    FOREIGN KEY (DeptID) REFERENCES Department(DeptID)
);

CREATE TABLE Performance (
    EmpID INT,
    ProjectID INT,
    Rating INT,
    ReviewDate DATE,
    PRIMARY KEY (EmpID, ProjectID),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID),
    FOREIGN KEY (ProjectID) REFERENCES Project(ProjectID)
);

CREATE TABLE Reward (
    EmpID INT,
    RewardMonth DATE,
    RewardAmount INT,
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID)
);

CREATE INDEX idx_empname ON Employee(EmpName);
CREATE INDEX idx_deptid ON Employee(DeptID);

INSERT INTO Department VALUES
(101,'IT','Bangalore'),
(102,'HR','Delhi'),
(103,'Finance','Mumbai'),
(104,'Marketing','Hyderabad'),
(105,'Sales','Chennai');

INSERT INTO Employee VALUES
(1,'Asha','F','1990-07-12','2018-06-10',101),
(2,'Raj','M','1988-04-09','2020-03-22',102),
(3,'Neha','F','1995-01-15','2021-08-05',101),
(4,'Arjun','M','1992-10-21','2019-02-12',103),
(5,'Priya','F','1993-11-30','2022-01-10',104);

INSERT INTO Project VALUES
(201,'ERP System',101,'2021-01-01','2022-01-01'),
(202,'HR Portal',102,'2020-05-01','2021-05-01'),
(203,'Finance Tracker',103,'2021-06-01','2022-06-01'),
(204,'Marketing AI',104,'2022-03-01','2023-03-01'),
(205,'Sales CRM',105,'2022-05-01','2023-05-01');

INSERT INTO Performance VALUES
(1,201,4,'2022-02-10'),
(2,202,3,'2021-07-15'),
(3,201,5,'2022-04-20'),
(4,203,4,'2022-05-12'),
(5,204,5,'2023-01-10');

INSERT INTO Reward VALUES
(1,'2023-01-01',2500),
(2,'2023-02-01',1500),
(3,'2023-03-01',3000),
(4,'2023-01-01',800),
(5,'2023-04-01',2200);

UPDATE Employee
SET DeptID = 103
WHERE EmpID = 2;

DELETE FROM Reward
WHERE RewardAmount < 1000;

SELECT *
FROM Employee
WHERE HireDate > '2019-01-01';

SELECT d.DeptName, AVG(p.Rating) AS AvgRating
FROM Performance p
JOIN Employee e ON p.EmpID = e.EmpID
JOIN Department d ON e.DeptID = d.DeptID
GROUP BY d.DeptName;

SELECT EmpName,
TIMESTAMPDIFF(YEAR, DOB, CURDATE()) AS Age
FROM Employee;

SELECT SUM(RewardAmount) AS TotalReward
FROM Reward
WHERE YEAR(RewardMonth) = YEAR(CURDATE());

SELECT e.EmpName, r.RewardAmount
FROM Employee e
JOIN Reward r ON e.EmpID = r.EmpID
WHERE r.RewardAmount > 2000;

SELECT 
e.EmpName,
d.DeptName,
p.ProjectName,
pf.Rating
FROM Employee e
JOIN Department d ON e.DeptID = d.DeptID
JOIN Performance pf ON e.EmpID = pf.EmpID
JOIN Project p ON pf.ProjectID = p.ProjectID;

SELECT EmpName
FROM Employee
WHERE EmpID NOT IN (
    SELECT EmpID
    FROM Reward
);

EXPLAIN
SELECT e.EmpName, d.DeptName
FROM Employee e
JOIN Department d
ON e.DeptID = d.DeptID;